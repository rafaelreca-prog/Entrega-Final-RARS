import dataset
miBase = dataset.connect("sqlite:///datos.db")
tabla = miBase["Productos"]

while True:
    opciones = input("""
    L - Listar
    A - Agregar
    Q - Quitar Por Nombre
    I - Quitar Por ID
    B - Buscar
    S - Salir
    
    """)
    match opciones:

        case "S":
            break
            
        case "A":
            nombreProducto = input("\nNombre: ")
            precioProducto = float(input("\nPrecio: "))
            categoriaProducto = input("\nCategoria: ")
        
            productoAgregar = {"Nombre":nombreProducto,"Precio":precioProducto,"Categoria":categoriaProducto}

            # diccionarios
            tabla.insert(productoAgregar)

        case "L":
            for cosa in tabla:
                print(f"ID: {cosa[id']} Nombre: {cosa['Nombre']}")
               
        case "Q":
            quitarProducto = input("\nProducto a quitar: ")
            tabla.delete(Nombre=quitarProducto)
            print(f"*** {quitarProducto} eliminado con exito ***")

        case "I":
            quitarProducto = int("\nProducto a quitar: ")
            tabla.delete(id=quitarProducto)
            print(f"*** Producto con ID: {quitarProducto} eliminado con exito ***")
