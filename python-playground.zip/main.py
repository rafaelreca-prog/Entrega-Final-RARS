print("Welcome to Online IDE!")
print("Start coding in Python...")

def sum(a, b):
    return a + b

a = int(input("Enter a number: "))
b = int(input("Enter another number: "))
print(f"The sum of {a} and {b} is {sum(a, b)}")
